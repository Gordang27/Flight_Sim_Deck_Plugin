Flight Sim Deck Bridge Plugin
=============================

Website: https://flightsimdeck.app/

Installation Instructions:
--------------------------
1. Locate your X-Plane installation folder (e.g., "C:\X-Plane 12").
2. Navigate to "Resources" -> "plugins".
3. Copy the entire "FlightSimDeckBridge" folder into this "plugins" directory.

The final path should look like:
.../X-Plane 12/Resources/plugins/FlightSimDeckBridge/

Restart X-Plane for the changes to take effect.
